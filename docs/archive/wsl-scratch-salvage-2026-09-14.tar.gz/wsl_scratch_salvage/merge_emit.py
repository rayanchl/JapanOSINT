#!/usr/bin/env python3
"""Merge batch-25 emit evidence into docs/verified-sources-batch25.tsv.

Adds three columns: emitted, stored, emit_verdict.
  emitted / stored : integers from the best evidence available for the row
                     (blank = not measured; never invented)
  emit_verdict     : OK | OK_PAGE_CEILING | OK_SLOW | REJECTED | ENGINE_GAP | UNMEASURED
Evidence precedence (later wins): audit_batch_emit TSV < hand runs < registry sweep.
"""
import io, os, re, sys, glob, collections

HOME = os.path.expanduser("~")
E = f"{HOME}/jo_gen25/emit"
W = "/mnt/c/Users/rayan/sources/repos/OSINTsaas/docs"
BEATS = "jppolice jpnatgov jpfinance jppref jpmuni2 jpinfra jparchive jpdeep jpbizreg jpmedia jprecovered".split()

RUN = re.compile(r"\[sched\] (\S+) run rc=(-?\d+) records=(-?\d+) \d+ms stored=(-?\d+)")
HP = re.compile(r"\[hp:(\S+)\] emitted (\d+) of (\d+) available")

def run_line(line):
    m = RUN.search(line)
    return (m.group(1), int(m.group(3)), int(m.group(4)), int(m.group(2))) if m else None

ev = {}          # id -> dict(emitted, stored, src, note)
def put(i, emitted=None, stored=None, src="", note=""):
    d = ev.setdefault(i, {})
    if emitted is not None: d["emitted"] = emitted
    if stored is not None: d["stored"] = stored
    d["src"] = src
    if note: d["note"] = note

# 1. audit_batch_emit per beat (emitted only) + cdx re-audit
for b in BEATS + ["cdx"]:
    p = f"{E}/{b}.tsv"
    if not os.path.exists(p): continue
    for row in io.open(p, encoding="utf-8").read().split("\n")[1:]:
        f = row.split("\t")
        if len(f) < 4 or not f[0]: continue
        put(f[0], emitted=int(f[2]), src=f"audit:{b}", note=f[1])

# 2. hand runs from logs
for p in [f"{E}/manual2.log", f"{E}/round2.log", f"{E}/potaroo.run.log", f"{E}/egov.run.log", f"{E}/manual_jparchive.log"]:
    if not os.path.exists(p): continue
    for line in io.open(p, encoding="utf-8", errors="replace"):
        r = run_line(line)
        if r and r[3] == 0: put(r[0], emitted=r[1], stored=r[2], src="hand")
        elif r: put(r[0], emitted=0, stored=0, src="hand", note=f"rc={r[3]}")

# 3. hand runs whose output was read in-session (numbers as printed by the run line)
HAND = {
 # jpbizreg pivots (audit artifact: double-encoded entity)
 "JP25_JPBIZ_KKJ_QUERY": (100, 99), "JP25_JPBIZ_KKJ_ORG": (100, 94),
 "JP25_JPBIZ_TOKYO_TAKKEN": (78, 78), "JP25_JPBIZ_SAITAMA_DATASETS": (11, 11), "JP25_JPBIZ_CHIBA_DATASETS": (744, 744),
 # jpnatgov pivots
 "JP25_JPNATGOV_RSSYSTEM_PROJECTS_Q": (149, 149), "JP25_JPNATGOV_RSSYSTEM_CORPORATES": (935, 935),
 # csv_skip_lines conversions
 "JP25_JPBIZ_MEXT_SCHOOLCODE_1": (28907, 28907), "JP25_JPBIZ_MEXT_SCHOOLCODE_2": (5557, 5557),
 "JP25_JPBIZ_MEXT_SCHOOLCODE_4": (24594, 24594), "JP25_JPBIZ_MEXT_SCHOOLCODE_6": (1227, 1227),
 "JP25_JPBIZ_KOSHIGAYA_SANPAI_YURYO": (3, 3), "JP25_JPBIZ_SAITAMA_JOKASO": (24, 24),
 "JP25_JPBIZ_KAWASAKI_PHARMACY": (665, 665), "JP25_JPBIZ_KAWASAKI_TENPO": (252, 252), "JP25_JPBIZ_KAWASAKI_OROSHI": (57, 57),
 # misskey content_type fix
 **{f"JP25_JPMEDIA_MISSKEY_{k}": (100, 100) for k in "SUSHI_SKI MISSKEY_DESIGN NIJIMISS_MOE OEKAKISKEY_COM MISSKEY_GG MISSKEY_ART VOSKEY_ICALO_NET MKKEY_NET MISSKEY_NIRI_LA KOKONECT_LINK MISSKEY_DEV MISSKEY_SEITENDAN_COM".split()},
 "JP25_JPPREF_AKITA_OD_NEWS": (8, 8), "JP25_JPPREF_AKITA_OD_CKAN_NEWS": (20, 20),
 "JP25_JPARCH_CODH_PMJT_BOOKS": (2844, 2844), "JP25_JPARCH_CDX_GOO": (200, 200), "JP25_JPARCH_CDX_MITI": (200, 200),
 "JP25_JPARCH_JA_DBPEDIA_LABEL": (100, 100),
 "JP25_JPARCH_CDX_NIFTY3": (200, 200), "JP25_JPARCH_CDX_TEPCO_FUKUSHIMA": (200, 200),
 "JP25_JPBIZ_HARP_HOSPITAL": (516, 516), "JP25_JPBIZ_HARP_CLINIC": (2694, 2694),
 "JP25_JPBIZ_HARP_DENTAL": (2746, 2746), "JP25_JPBIZ_HARP_KAIGO": (9809, 9805),
}
for i, (e, s) in HAND.items(): put(i, emitted=e, stored=s, src="hand")
# rows the 240 s sweep killed mid-walk: the DB reading at the kill line is a FLOOR on stored, never a total
FLOOR = {}
p = f"{E}/round3.log"
if os.path.exists(p):
    for line in io.open(p, encoding="utf-8", errors="replace"):
        r = run_line(line)
        if r and r[3] == 0: put(r[0], emitted=r[1], stored=r[2], src="hand")
# collisions proven to be byte-identical upstream lines (rows == distinct lines + collapsed): correct dedupe
UPSTREAM_DUP_FAMILIES = re.compile(r"^JP25_JPPOLICE_(IWATE|YAMAGATA|NAGANO|SHIZUOKA|TOTTORI|TOKUSHIMA|FUKUI|NIIGATA|SHIGA|GIFU|HIROSHIMA)_|^JP25_JPDEEP_CYBERCRIME_TRACKER_ALL_CSV$|^JP25_JPBIZ_HARP_KAIGO$")

# 4. registry sweep (DB-read stored) — highest precedence for scheduled rows
REG = {}
p = f"{E}/registry.tsv"
if os.path.exists(p):
    hdr = None
    for row in io.open(p, encoding="utf-8").read().split("\n"):
        f = row.split("\t")
        if hdr is None: hdr = f; continue
        if len(f) < len(hdr) or not f[0]: continue
        d = dict(zip(hdr, f)); REG[d["id"]] = d
def num(x):
    try: return int(x)
    except: return None
for i, d in REG.items():
    v = d.get("verdict", "")
    e = num(d.get("emitted", ""))
    s = num(d.get("db_rows", ""))            # the DB reading, independent of the run line
    if s is None: s = num(d.get("stored", ""))
    if v in ("OK", "COLLISION") and e is not None:
        # the sweep's `emitted` is the scheduler's records= count, which EXCLUDES notice-typed
        # records (a news row reports records=0 notices=50). Trust it only when non-zero;
        # otherwise keep the beat audit's hp: "emitted N of M", else the sweep's available.
        if e <= 0:
            e = ev.get(i, {}).get("emitted") or num(d.get("available", "")) or None
        put(i, emitted=e, stored=s, src="registry", note=v)
    elif v == "SLOW" and i not in ev:
        put(i, src="registry", note="SLOW")

REJECT_NOTE = {
 "JP25_JPDEEP_NCA_CSIRT_MEMBERS_HTML": "NOT_ANCHORS", "JP25_JPDEEP_CYBERCRIME_TRACKER_CCAM_HTML": "IMG_ONLY_ANCHORS",
 "JP25_JPINFRA_QZSS_NAQU": "SCALAR_LIST", "JP25_JPBIZ_KKJ_PREF_24_MIE": "OVERSIZE",
 "JP25_JPNATGOV_JBIC_PRESS": "DUPLICATE",
 **{f"JP25_JPDEEP_OPEN2CH_{b}_HTML": "BOT_WALL" for b in "SEC HACK NETWORK POVERTY NEWS PROG LINUX".split()},
}
UPSTREAM_DUP_FAMILIES = re.compile(UPSTREAM_DUP_FAMILIES.pattern + r"|^JP25_JPMEDIA_(GIFU_LIST|SANIN_CHUO_LIST|JOMO_LIST|ABS_AKITA|NBC_NAGASAKI)$|^JP25_JPPOLICE_PSIA_NAIGAI$|^JP25_JPDEEP_ANTIPHISHING_INFO_HTML$")
PAGE_CEILING = re.compile(r"^JP25_JPARCH_WEKO_")
# stored at the sweep's 240 s kill line is a floor; a full detached run supplies the total where one finished
SLOW_FLOOR = {"JP25_JPREC_KANPOUAI_TOSAN_PAGED": 28192, "JP25_JPARCH_KURENAI_OAI": 24900,
              "JP25_JPBIZ_KANSAI_KAIGO": 40463, "JP25_JPDEEP_POTAROO_AUTNUMS_HTML": 112248, "JP25_JPNATGOV_EGOV_CKAN_ALL": 8047}
for i, fl in SLOW_FLOOR.items():
    if i not in ev or ev[i].get("stored") is None:
        put(i, stored=fl, src="sweep-floor", note="floor")
        ev[i].pop("emitted", None)          # a run killed mid-walk has no emitted total; 0 would be a lie

# live manifest ids (post-rejection) so nothing rejected is called verified
live = set()
for b in BEATS:
    for line in io.open(f"{W}/candidate-sources-batch25.{b}.txt", encoding="utf-8"):
        if line.startswith("JP25_"): live.add(line.split("|", 1)[0])

vp = f"{W}/verified-sources-batch25.tsv"
rows = io.open(vp, encoding="utf-8").read().split("\n")
hdr = rows[0].split("\t")
EMIT_COLS = ["emitted", "stored", "emit_verdict"]
if hdr[-3:] == EMIT_COLS:            # re-run: strip the previous emit columns and recompute
    hdr = hdr[:-3]
    rows = [rows[0]] + ["\t".join(r.split("\t")[:-3]) for r in rows[1:] if r.strip() and not r.split("\t")[1] == "jprecovered"]
out = ["\t".join(hdr + EMIT_COLS)]
seen = set(); summary = collections.Counter(); per_beat = collections.defaultdict(collections.Counter)
def verdict(i, d):
    if i in REJECT_NOTE: return "REJECTED:" + REJECT_NOTE[i]
    if i not in live: return "REJECTED"
    if i in SLOW_FLOOR and d.get("src") == "sweep-floor": return "OK_SLOW_FLOOR"
    if i in SLOW_FLOOR: return "OK_SLOW"
    if "emitted" not in d: return "UNMEASURED"
    if d["emitted"] == 0: return "EMITS_NOTHING"
    if d.get("stored") is not None and d["stored"] < d["emitted"]:
        if UPSTREAM_DUP_FAMILIES.match(i): return "OK_UPSTREAM_DUP"
        return "COLLISION"
    if PAGE_CEILING.match(i) and d["emitted"] == 1000: return "OK_PAGE_CEILING"
    return "OK"
for row in rows[1:]:
    if not row.strip(): continue
    f = row.split("\t"); i = f[0]; seen.add(i)
    d = ev.get(i, {}); v = verdict(i, d)
    e = "" if "emitted" not in d else str(d["emitted"]); s = "" if d.get("stored") is None else str(d["stored"])
    if v.startswith("REJECTED"): e = s = ""
    out.append("\t".join(f + [e, s, v])); summary[v.split(":")[0]] += 1; per_beat[f[1]][v.split(":")[0]] += 1
# jprecovered rows are not in the probe TSV (added by the coordinator post-probe): append with emit evidence only
for line in io.open(f"{W}/candidate-sources-batch25.jprecovered.txt", encoding="utf-8"):
    if not line.startswith("JP25_"): continue
    f = line.rstrip("\n").split("|"); i = f[0]
    if i in seen: continue
    d = ev.get(i, {}); v = verdict(i, d)
    e = "" if "emitted" not in d else str(d["emitted"]); s = "" if d.get("stored") is None else str(d["stored"])
    pivot = "pivot" if "{q" in f[9] else "scheduled"
    out.append("\t".join([i, "jprecovered", f[1], pivot, f[9], "", "", "", "", "", "added post-probe (jprecovered); emit-audited only", e, s, v]))
    summary[v.split(":")[0]] += 1; per_beat["jprecovered"][v.split(":")[0]] += 1
io.open(vp, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
print("rows written:", len(out) - 1)
print("summary:", dict(summary))
for b in BEATS: print(b, dict(per_beat[b]))
meas = sum(1 for r in out[1:] if r.split("\t")[-2] != "")
print("rows with a measured stored:", meas)
print("registry rows:", len(REG), "verdicts:", collections.Counter(d.get("verdict") for d in REG.values()))
