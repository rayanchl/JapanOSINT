import csv

def load(path):
    rows = {}
    with open(path, encoding='utf-8') as f:
        r = csv.reader(f, delimiter='\t')
        header = next(r)
        for row in r:
            if not row:
                continue
            d = dict(zip(header, row))
            rows[d['id']] = d
    return rows

base = load('/home/rayan/jo_audit_2026_09_03/audit_run/reconstructed.tsv')
norun = load('/home/rayan/jo_audit_2026_09_03/audit_run/norun_recheck.tsv')
csr = load('/home/rayan/jo_audit_2026_09_03/audit_run/collision_slow_recheck.tsv')
final = load('/home/rayan/jo_audit_2026_09_03/audit_run/final_recheck.tsv')

# pivot (interval=0) ids -> excluded from broken tally
pivot_ids = set()
with open('/home/rayan/jo_audit_2026_09_03/audit_run/id_interval.tsv', encoding='utf-8') as f:
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) == 2 and parts[1] == 'interval=0':
            pivot_ids.add(parts[0])

merged = {}
for sid, row in base.items():
    final_row = final.get(sid) or csr.get(sid) or norun.get(sid) or row
    merged[sid] = final_row

tally = {}
collisions = []
emits_nothing_real = []
no_run_line_survivors = []
slow_final = []
for sid, row in merged.items():
    v = row['verdict']
    is_pivot = sid in pivot_ids
    cat = v
    if is_pivot and v in ('EMITS_NOTHING', 'NEEDS_ENTITY'):
        cat = 'PIVOT_UNTESTABLE'
    tally[cat] = tally.get(cat, 0) + 1
    if v == 'COLLISION':
        try:
            emitted = int(row['emitted']); stored = int(row['stored'])
            collisions.append((emitted - stored, sid, emitted, stored))
        except Exception:
            pass
    if v == 'EMITS_NOTHING' and not is_pivot:
        emits_nothing_real.append(sid)
    if v == 'NO_RUN_LINE':
        no_run_line_survivors.append(sid)
    if v == 'SLOW':
        slow_final.append(sid)

print('=== FINAL MERGED TALLY ===')
for k, v in sorted(tally.items(), key=lambda x: -x[1]):
    print(f'{k:20s} {v}')
print()
print('total ids:', len(merged))
print()
print('=== COLLISION: total records lost ===')
print(sum(c[0] for c in collisions))
print('=== TOP 25 COLLISION offenders by absolute records lost ===')
for loss, sid, e, s in sorted(collisions, key=lambda x: -x[0])[:25]:
    print(f'{sid:45s} lost={loss:6d} emitted={e:6d} stored={s:6d}')
print()
print('=== NO_RUN_LINE survivors (still dying after 2 rechecks) ===', len(no_run_line_survivors))
for sid in no_run_line_survivors[:30]:
    print(' ', sid)
print()
print('=== real EMITS_NOTHING (non-pivot) count ===', len(emits_nothing_real))

with open('/home/rayan/jo_audit_2026_09_03/audit_run/final_collision.tsv', 'w') as f:
    f.write('id\temitted\tstored\tlost\tpct_lost\n')
    for loss, sid, e, s in sorted(collisions, key=lambda x: -x[0]):
        pct = round(100*loss/e, 1) if e else 0
        f.write(f'{sid}\t{e}\t{s}\t{loss}\t{pct}\n')

with open('/home/rayan/jo_audit_2026_09_03/audit_run/final_emits_nothing.txt', 'w') as f:
    for sid in sorted(emits_nothing_real):
        f.write(sid + '\n')
