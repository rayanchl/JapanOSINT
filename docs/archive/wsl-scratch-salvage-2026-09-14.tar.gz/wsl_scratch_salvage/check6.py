import re, json, socket, urllib.request, ssl, gzip, html as H, time, sys
_orig = socket.getaddrinfo
def _gai(*a, **k):
    r = _orig(*a, **k); v4 = [x for x in r if x[0] == socket.AF_INET]; return v4 or r
socket.getaddrinfo = _gai
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA = "Mozilla/5.0 (X11; Linux x86_64) JapanOSINT/1.0"
def get(url, ua=UA):
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept": "*/*", "Accept-Encoding": "gzip"})
    with urllib.request.urlopen(req, timeout=40, context=ctx) as r:
        b = r.read(4000000)
        if r.headers.get("Content-Encoding")=="gzip":
            try: b=gzip.decompress(b)
            except Exception: pass
    for enc in ("utf-8","cp932","euc-jp"):
        try: return b.decode(enc)
        except Exception: pass
    return b.decode("utf-8","replace")
def body(url, n=1800, ua=UA):
    print("=====B", url)
    try: t=get(url, ua); print("  ", re.sub(r"\s+"," ",t[:n]))
    except Exception as e: print("  ERR", str(e)[:120])
def hm(url, must, base=None):
    print("=====H", url, "must=", must)
    try: t=get(url)
    except Exception as e: print("  ERR", str(e)[:120]); return
    hrefs = re.findall(r'<a\b[^>]*?href="([^"#]+)"[^>]*>(.*?)</a>', t, re.S|re.I)
    m=[(h, re.sub(r"\s+"," ",H.unescape(re.sub(r"<[^>]+>","",a))).strip()) for h,a in hrefs if must in h]
    print("  anchors=%d match=%d distinct=%d" % (len(hrefs), len(m), len(set(h for h,_ in m))))
    for x in m[:4]: print("    ", x[0][:90], "|", x[1][:70])
    for x in m[-2:]: print("    ", x[0][:90], "|", x[1][:70])
body("https://api.jstage.jst.go.jp/searchapi/do?service=3&article=%22zzqx9nonexistent7q%22&count=100", 2500)
body("https://api.jstage.jst.go.jp/searchapi/do?service=2&material=%22zzqx9nonexistent7q%22&count=100", 2500)
body("https://api.jstage.jst.go.jp/searchapi/do?service=2&material=%22%E5%9C%B0%E9%9C%87%22&count=100", 2500)
body("https://irdb.nii.ac.jp/oai?verb=ListRecords&metadataPrefix=oai_dc", 800)
body("https://irdb.nii.ac.jp/oai?verb=ListRecords&metadataPrefix=oai_dc&from=2026-08-20", 1500)
body("https://irdb.nii.ac.jp/oai?verb=ListSets", 800)
body("https://www.mitsubishielectric.co.jp/psirt/vulnerability/xml/info.xml", 1500)
body("http://feeds.feedburner.com/elecom_news", 1200)
body("https://api.github.com/repos/JPCERTCC/phishurl-list/contents/2026", 600)
body("https://www.jpnap.net/ix/customer.php", 300)
hm("https://www.jpnap.net/ix/customer.php", "as")
body("https://vne-info.jpix.ad.jp/history", 1200)
body("https://customer.jpix.ad.jp/", 800)
hm("https://cs.cybozu.co.jp/rss/", "rss")
body("https://www.fujitsu.com/jp/products/software/resources/condition/security/index.html", 300)
body("https://togetter.com/search?q=%E5%9C%B0%E9%9C%87&t=q&page=2", 200)
hm("https://togetter.com/search?q=%E5%9C%B0%E9%9C%87&t=q&page=2", "/li/")
t1=get("https://hayabusa.open2ch.net/newsplus/subject.txt"); time.sleep(1); t2=get("https://uni.open2ch.net/newsplus/subject.txt")
print("open2ch newsplus hayabusa==uni:", t1[:300]==t2[:300], t1[:80], "||", t2[:80])
t=get("https://jvn.jp/jp/"); i=t.find("JVN"); 
for mm in list(re.finditer(r'<a[^>]+href="([^"]*JVN[^"]*)"[^>]*>(.*?)</a>', t, re.S))[:3]: print("jvn/jp anchor:", mm.group(1), re.sub(r"\s+"," ",mm.group(2))[:80])
hm("https://jvn.jp/jp/", "JVN")
hm("https://www.jpcert.or.jp/newsflash/", "20")
hm("https://www.jpcert.or.jp/wr/", "/wr/20")
hm("https://www.jpcert.or.jp/tsubame/report/", "/tsubame/report/report")
hm("https://jvn.jp/vu/", "/vu/JVNVU")
hm("https://jvn.jp/en/vu/", "/en/vu/JVNVU")
hm("https://jvn.jp/en/jp/", "/en/jp/JVN")
hm("https://www.ipa.go.jp/security/security-alert/index.html", "/security/security-alert/")
hm("https://www.elecom.co.jp/news/security/", "/news/security/20")
hm("https://blog.nicter.jp/", "blog.nicter.jp/20")
hm("https://www.ict-isac.jp/news/", "news20")
hm("https://www.kansai-airport.or.jp/flight/", "/flight/detail/")
hm("https://www.otit.go.jp/news/", "/news/cat")
hm("https://www.jaxa.jp/press/2026/index_j.html", "/press/2026/")
hm("https://kanpou.npb.go.jp/", "0000f.html")
hm("https://www.fsa.go.jp/en/news/index.html", "/en/news/20")
hm("https://www.jpx.co.jp/listing/market-alerts/supervision/index.html", "/listing/market-alerts/")
hm("https://www.jpx.co.jp/listing/stocks/delisted/index.html", "delisted")
