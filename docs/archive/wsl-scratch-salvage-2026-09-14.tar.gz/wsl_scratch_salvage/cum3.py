import csv, os
D='/home/rayan/jo_audit_2026_09_03/audit_run'
def load(p):
    r={}
    if os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            for row in csv.DictReader(f, delimiter='\t'): r[row['id']]=row
    return r
base=load(f'{D}/fixpass_sweep.tsv')
lay=[load(f'{D}/round3_sweep.tsv'), load(f'{D}/r45_sweep.tsv'),
     load(f'{D}/r67_sweep.tsv'), load(f'{D}/socrata_sweep.tsv')]
# IANA + FVG fixed by hand after their last sweep
manual={'IANA_LANGUAGE_SUBTAGS':('OK',9297,9297),'IT_FVG_MOBILE_SITES':('OK',6103,6103)}
cur={}
for s in base:
    row=None
    for L in reversed(lay):
        if s in L: row=L[s]; break
    cur[s]=row or base[s]
tally={}; lost=0
for s,r in cur.items():
    v=r['verdict']
    if s in manual: v='OK'
    tally[v]=tally.get(v,0)+1
    if v=='COLLISION':
        try: lost+=max(int(r['emitted'])-int(r['stored']),0)
        except: pass
print('=== CUMULATIVE (original 1,770 defective ids) ===')
for k,v in sorted(tally.items(), key=lambda x:-x[1]): print(f'  {k:16s} {v}')
print(f'\n  collision records lost per pass: {lost:,}   (start 205,617)')
print(f'  recovered: {205617-lost:,}')
print('\n  NOTE: gr-diavgeia-positions is proven case-B (correct dedupe);')
print('        its 24,932 is counted above but is not real loss.')
print(f'  real remaining loss excluding it: {lost-24932:,}')
