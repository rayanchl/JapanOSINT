#!/usr/bin/env python3
"""Prove or disprove the uid_instability findings against live data.

The claim is that these collectors derive their uid from something that changes
between runs, so a second run INSERTS duplicates instead of updating in place.
That is directly testable: run the same source twice into the same database and
compare row counts.

  run1 == run2   -> uid is stable, the finding is wrong (or the field it depends
                    on happened not to move between the two runs)
  run2 == 2*run1 -> every row duplicated: uid fully unstable
  in between     -> partially unstable

Anything that returns 0 rows on the first run is reported as untestable rather
than as a pass, so an unconfigured or blocked source can't be mistaken for proof.
"""
import json
import os
import subprocess
import sqlite3
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor

NATIVE = os.path.expanduser("~/joaudit/native")
BIN = os.path.join(NATIVE, "bin", "japanosint")
SCHEMA = os.path.join(NATIVE, "core", "schema.sql")


def count(db, sid):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=20)
    try:
        return con.execute(
            "SELECT COUNT(*) FROM intel_items WHERE source_id=?", (sid,)
        ).fetchone()[0]
    finally:
        con.close()


def check(sid, timeout=90):
    tmp = tempfile.mkdtemp(prefix="uidchk_")
    db = os.path.join(tmp, "t.db")
    env = dict(os.environ, JO_DB=db, JO_SCHEMA=SCHEMA)
    out = {"id": sid, "run1": None, "run2": None, "verdict": "?"}
    try:
        for k in ("run1", "run2"):
            try:
                subprocess.run([BIN, "--run", sid], env=env, timeout=timeout,
                               capture_output=True, cwd=NATIVE)
            except subprocess.TimeoutExpired:
                out["verdict"] = "TIMEOUT"
                return out
            out[k] = count(db, sid)
        a, b = out["run1"], out["run2"]
        if not a:
            out["verdict"] = "UNTESTABLE_no_rows"
        elif b == a:
            out["verdict"] = "STABLE"
        elif b >= 2 * a:
            out["verdict"] = "DUPLICATES_ALL"
        else:
            out["verdict"] = "DUPLICATES_PARTIAL"
        out["growth"] = None if not a else round(b / a, 2)
    except Exception as e:
        out["verdict"] = f"ERR:{type(e).__name__}"
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    return out


def main():
    ids = [x.strip() for x in open(sys.argv[1]) if x.strip()]
    jobs = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    res = []
    with ThreadPoolExecutor(jobs) as ex:
        for r in ex.map(check, ids):
            res.append(r)
            print(f"  {r['id']:30s} {r['verdict']:20s} "
                  f"run1={r['run1']} run2={r['run2']} x{r.get('growth')}",
                  flush=True)
    print("\n=== summary ===")
    from collections import Counter
    for k, v in Counter(r["verdict"] for r in res).most_common():
        print(f"  {k:22s} {v}")
    json.dump(res, open("/tmp/joaudit/uid_verify.json", "w"), indent=1)


if __name__ == "__main__":
    main()
