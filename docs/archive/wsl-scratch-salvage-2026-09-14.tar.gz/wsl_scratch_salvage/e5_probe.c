/* e5_probe.c — drive core/service_vec.c against a REAL embedding model and
 * print the routing decisions, so "it works" is a set of service names a
 * person can judge rather than an exit code.
 *
 * Not a unit test: it needs a running llama-server and a 575 MB model, so it
 * lives in the scratchpad and is run by hand. tests/unit/test_service_vec.c is
 * the CI-safe version (stub server, skips when python3 is absent).
 *
 * Build: see run_real_embed.sh, which takes the link line from
 *        `make print-ldlibs` rather than re-deriving it. */
#include "../../core/service_vec.c"
#include <stdio.h>

static void ask(db_handle *db, const char *q) {
  char **ids = NULL;
  int n = 0;
  char *cat = service_vec_catalogue(db, q, 8, NULL, &ids, &n);
  printf("\n  \"%s\"\n", q);
  if (!cat) {
    printf("      (no semantic route — fell back to registry order)\n");
    return;
  }
  for (int i = 0; i < n; i++) printf("      %d. %s\n", i + 1, ids[i]);
  service_vec_free_ids(ids, n);
  free(cat);
}

int main(void) {
  const char *dbp = getenv("JO_DB");
  db_handle db;
  if (!dbp || db_open(&db, dbp, NULL) != 0) {
    fprintf(stderr, "e5_probe: set JO_DB\n");
    return 2;
  }
  int n = service_vec_build(&db);
  printf("  service index: %d entity-pivot services\n", n);
  if (n <= 0) {
    fprintf(stderr, "  index not built (is JO_EMBED_URL up?)\n");
    db_close(&db);
    return 1;
  }
  char *dim = svec_meta_get(&db, "dim");
  char *model = svec_meta_get(&db, "model");
  printf("  dim=%s model=%s\n", dim ? dim : "?", (model && *model) ? model : "(unset)");
  free(dim);
  free(model);

  /* Questions a person would actually type. Each one is asking for a DIFFERENT
   * family of service, so a router that works should return visibly different
   * menus — and the ones a human would name should be near the top. */
  ask(&db, "who owns the domain example.com and who registered it");
  ask(&db, "recent earthquakes and tsunami warnings in Japan");
  ask(&db, "is this IP address a known malware command and control server");
  ask(&db, "find social media profiles for this username");
  ask(&db, "company registration and corporate filings for a business");
  ask(&db, "flights and aircraft currently in the air");

  db_close(&db);
  printf("\n");
  return 0;
}
