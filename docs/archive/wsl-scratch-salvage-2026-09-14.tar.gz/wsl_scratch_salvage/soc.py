import csv, os
D='/home/rayan/jo_audit_2026_09_03/audit_run'
def load(p):
    r={}
    if os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            for row in csv.DictReader(f, delimiter='\t'): r[row['id']]=row
    return r
base=load(f'{D}/fixpass_sweep.tsv'); r3=load(f'{D}/round3_sweep.tsv')
r45=load(f'{D}/r45_sweep.tsv'); r67=load(f'{D}/r67_sweep.tsv'); soc=load(f'{D}/socrata_sweep.tsv')
ids=[l.strip() for l in open(f'{D}/socrata52.txt') if l.strip()]
before_lost=0; before_ok=0; tracked=0
for s in ids:
    prev = r67.get(s) or r45.get(s) or r3.get(s) or base.get(s)
    if not prev: continue
    tracked+=1
    if prev['verdict']=='OK': before_ok+=1
    if prev['verdict']=='COLLISION':
        try: before_lost += max(int(prev['emitted'])-int(prev['stored']),0)
        except: pass
print(f'  of the 52, previously measured: {tracked}')
print(f'    were already OK      : {before_ok}')
print(f'    records lost BEFORE  : {before_lost:,}')
print(f'    records lost AFTER   : 0')
