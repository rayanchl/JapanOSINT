import sys

D = '/home/rayan/jo_audit_2026_09_03/audit_run'
N = 10
items = []
with open(f'{D}/file_weights.txt', encoding='utf-8') as f:
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) != 2:
            continue
        items.append((int(parts[0]), parts[1]))

items.sort(key=lambda x: -x[0])
bins = [[] for _ in range(N)]
loads = [0]*N
for w, f in items:
    i = loads.index(min(loads))
    bins[i].append(f)
    loads[i] += w

for i in range(N):
    with open(f'{D}/group_{i}.txt', 'w') as out:
        out.write('\n'.join(bins[i]) + '\n')
    print(f'group {i}: {len(bins[i])} files, weight {loads[i]}')
