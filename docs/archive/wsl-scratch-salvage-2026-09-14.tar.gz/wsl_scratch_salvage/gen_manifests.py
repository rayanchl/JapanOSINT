import csv, subprocess, os

D = '/home/rayan/jo_audit_2026_09_03/audit_run'
ROOT = '/mnt/c/Users/rayan/sources/repos/OSINTsaas'

collisions = {}
with open(f'{D}/../../../.././../..' , 'r') if False else open(os.path.join(ROOT, 'docs/source-audit-2026-09-04-collisions.tsv'), encoding='utf-8') as f:
    r = csv.DictReader(f, delimiter='\t')
    for row in r:
        collisions[row['id']] = row

emits_nothing = set()
with open(os.path.join(ROOT, 'docs/source-audit-2026-09-04-emits-nothing.txt'), encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if line:
            emits_nothing.add(line)

for i in range(10):
    with open(f'{D}/group_{i}.txt', encoding='utf-8') as f:
        files = [x.strip() for x in f if x.strip()]
    lines = []
    for fpath in files:
        full = os.path.join(ROOT, fpath)
        try:
            with open(full, encoding='utf-8', errors='replace') as ff:
                content = ff.read()
        except FileNotFoundError:
            continue
        # find ids in this file (either verdict list) that are quoted in the file
        hits = []
        for sid in collisions:
            if f'"{sid}"' in content:
                hits.append(('COLLISION', sid, collisions[sid]))
        for sid in emits_nothing:
            if f'"{sid}"' in content:
                hits.append(('EMITS_NOTHING', sid, None))
        if hits:
            lines.append(f'## {fpath}  ({len(hits)} defective ids)')
            for kind, sid, row in hits:
                if kind == 'COLLISION':
                    lines.append(f'  COLLISION  {sid}\temitted={row["emitted"]} stored={row["stored"]} lost={row["lost"]} ({row["pct_lost"]}%)')
                else:
                    lines.append(f'  EMITS_NOTHING  {sid}')
    with open(f'{D}/manifest_{i}.txt', 'w', encoding='utf-8') as out:
        out.write('\n'.join(lines) + '\n')
    print(f'group {i}: manifest written, {len(lines)} lines')
