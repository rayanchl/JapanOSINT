import csv
D='/home/rayan/jo_audit_2026_09_03/audit_run'
old = {}
old_loss = {}
with open(f'{D}/final_collision.tsv', encoding='utf-8') as f:
    for r in csv.DictReader(f, delimiter='\t'):
        old[r['id']] = 'COLLISION'; old_loss[r['id']] = int(r['lost'])
with open(f'{D}/final_emits_nothing.txt', encoding='utf-8') as f:
    for line in f:
        s=line.strip()
        if s: old[s]='EMITS_NOTHING'
new = {}
with open(f'{D}/fixpass_sweep.tsv', encoding='utf-8') as f:
    for r in csv.DictReader(f, delimiter='\t'):
        new[r['id']] = r
print('original defective ids:', len(old), ' re-swept:', len(new))
trans = {}
still_coll_C, still_coll_other, still_en, now_ok, other_new = [], [], [], [], []
loss_before = sum(old_loss.values()); loss_after = 0
for sid, ov in old.items():
    r = new.get(sid)
    if not r: trans[(ov,'MISSING')] = trans.get((ov,'MISSING'),0)+1; continue
    nv = r['verdict']
    trans[(ov,nv)] = trans.get((ov,nv),0)+1
    if nv == 'OK': now_ok.append(sid)
    elif nv == 'COLLISION':
        e, s = int(r['emitted']), int(r['stored'])
        loss_after += max(e-s,0)
        ratio = s/e if e else 0
        if e>0 and abs(ratio-0.5)<1e-9 or abs(ratio-1/3)<1e-9 or abs(ratio-2/3)<1e-9 or abs(ratio-0.25)<1e-9 or abs(ratio-0.75)<1e-9:
            still_coll_C.append(sid)
        else:
            still_coll_other.append(sid)
    elif nv == 'EMITS_NOTHING': still_en.append(sid)
    else: other_new.append((sid,nv))
print()
print('=== transitions old -> new ===')
for k,v in sorted(trans.items(), key=lambda x:-x[1]): print(f'{k[0]:14s} -> {k[1]:14s} {v}')
print()
print('now OK (fixed by agents):', len(now_ok))
print('still COLLISION, exact page-fraction (case C, engine fix pending):', len(still_coll_C))
print('still COLLISION, other (case A or B, needs triage):', len(still_coll_other))
print('still EMITS_NOTHING:', len(still_en))
print('other new verdicts:', len(other_new), other_new[:10])
print()
print('collision records lost: before', loss_before, ' after', loss_after)
for name, lst in [('remain_collision_caseC',still_coll_C),('remain_collision_other',still_coll_other),('remain_emits_nothing',still_en),('fixed_ok',now_ok)]:
    with open(f'{D}/{name}.txt','w') as f: f.write('\n'.join(sorted(lst))+('\n' if lst else ''))
