/* joq — minimal SQL runner for the collector audit. TSV out, NULL as \N. */
#include "sqlite3.h"
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv) {
  if (argc < 3) { fprintf(stderr, "usage: joq <db> <sql>\n"); return 2; }
  sqlite3 *h;
  if (sqlite3_open_v2(argv[1], &h, SQLITE_OPEN_READONLY, NULL) != SQLITE_OK) {
    fprintf(stderr, "open failed: %s\n", sqlite3_errmsg(h)); return 1;
  }
  sqlite3_busy_timeout(h, 15000);
  sqlite3_stmt *s;
  if (sqlite3_prepare_v2(h, argv[2], -1, &s, NULL) != SQLITE_OK) {
    fprintf(stderr, "prepare failed: %s\n", sqlite3_errmsg(h)); return 1;
  }
  int nc = sqlite3_column_count(s), first = 1;
  while (sqlite3_step(s) == SQLITE_ROW) {
    if (first) {
      for (int i = 0; i < nc; i++) printf("%s%s", i ? "\t" : "", sqlite3_column_name(s, i));
      printf("\n"); first = 0;
    }
    for (int i = 0; i < nc; i++) {
      if (i) putchar(9);
      if (sqlite3_column_type(s, i) == SQLITE_NULL) fputs("\N", stdout);
      else {
        const unsigned char *t = sqlite3_column_text(s, i);
        for (const unsigned char *p = t; p && *p; p++) putchar((*p=="\t"[0]||*p=="\n"[0]) ? " "[0] : *p);
      }
    }
    printf("\n");
  }
  sqlite3_finalize(s); sqlite3_close(h);
  return 0;
}
