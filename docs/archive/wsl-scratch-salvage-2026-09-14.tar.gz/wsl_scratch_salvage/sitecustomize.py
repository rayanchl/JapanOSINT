import socket
_orig = socket.getaddrinfo
def _gai(*a, **k):
    r = _orig(*a, **k); v4 = [x for x in r if x[0] == socket.AF_INET]; return v4 or r
socket.getaddrinfo = _gai
