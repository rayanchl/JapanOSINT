#!/usr/bin/env python3
"""Resilient wrapper around the audit harness.

Three things the base harness doesn't do, each of which cost us a full run:

  * RESUME. Results are appended, and ids already present in the output file are
    skipped. A teardown mid-sweep now costs only the in-flight sources instead
    of everything.
  * FAULT ISOLATION. `ThreadPoolExecutor.map` re-raises the first exception and
    abandons the remaining work — one source that trips an unexpected
    FileNotFoundError killed a 2201-source run at 126. Here each future is
    awaited individually and a thrown source is recorded as a HARNESS_ERROR row.
  * UNBUFFERED APPEND. Each result is flushed as it lands, so partial progress
    survives even a SIGKILL.

Usage mirrors audit_run.py; it imports that module so there is exactly one
definition of what a run means.
"""
import argparse
import importlib.util
import json
import os
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed


def load_harness(path):
    spec = importlib.util.spec_from_file_location("audit_run", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--harness", required=True)
    ap.add_argument("--ids", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--jobs", type=int, default=10)
    ap.add_argument("--timeout", type=int, default=90)
    a = ap.parse_args()

    H = load_harness(a.harness)

    done = set()
    if os.path.exists(a.out):
        with open(a.out, encoding="utf-8") as fh:
            for line in fh:
                try:
                    done.add(json.loads(line)["id"])
                except Exception:
                    pass

    specs = []
    with open(a.ids, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line.strip() or line.startswith("#"):
                continue
            parts = line.split("\t")
            sid = parts[0].strip()
            if sid in done:
                continue
            specs.append([sid, parts[1].strip() if len(parts) > 1 else ""])

    print(f"resume: {len(done)} already done, {len(specs)} to run, "
          f"{a.jobs} jobs, {a.timeout}s timeout", file=sys.stderr, flush=True)

    lock = threading.Lock()
    n = [0]
    with open(a.out, "a", encoding="utf-8") as fh, ThreadPoolExecutor(a.jobs) as ex:
        futs = {ex.submit(H.run_one, s, a.timeout, ""): s[0] for s in specs}
        for fut in as_completed(futs):
            sid = futs[fut]
            try:
                rec = fut.result()
                rec["verdict"] = H.verdict(rec)
            except Exception as e:
                # A harness fault is a finding about the harness, not about the
                # source — record it and keep the sweep alive.
                rec = {"id": sid, "verdict": "HARNESS_ERROR",
                       "harness_error": f"{type(e).__name__}: {e}",
                       "rows": 0, "geo_rows": 0, "rc": None}
            with lock:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
                fh.flush()
                os.fsync(fh.fileno())
                n[0] += 1
                if n[0] % 50 == 0:
                    print(f"  {n[0]}/{len(specs)}", file=sys.stderr, flush=True)
    print(f"done: +{n[0]} results -> {a.out}", file=sys.stderr, flush=True)


if __name__ == "__main__":
    main()
