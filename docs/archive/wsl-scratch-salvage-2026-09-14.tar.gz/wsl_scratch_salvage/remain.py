import csv, os, collections
D='/home/rayan/jo_audit_2026_09_03/audit_run'
def load(p):
    r={}
    if os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            for row in csv.DictReader(f, delimiter='\t'): r[row['id']]=row
    return r
base=load(f'{D}/fixpass_sweep.tsv'); r3=load(f'{D}/round3_sweep.tsv')
r45=load(f'{D}/r45_sweep.tsv');      r67=load(f'{D}/r67_sweep.tsv')
cur={s:(r67.get(s) or r45.get(s) or r3.get(s) or base[s]) for s in base}
coll=[(int(r['emitted'])-int(r['stored']), s, r) for s,r in cur.items()
      if r['verdict']=='COLLISION' and r['emitted'].lstrip('-').isdigit()]
coll.sort(reverse=True)
print('=== TOP 25 REMAINING COLLISIONS by records lost ===')
for lost,s,r in coll[:25]:
    print(f'  {lost:7,}  {s:44s} {r["emitted"]:>7}/{r["stored"]:<7}')
print()
en=[s for s,r in cur.items() if r['verdict']=='EMITS_NOTHING']
pref=collections.Counter()
for s in en:
    p=s.split('-')[0] if '-' in s else s.split('_')[0]
    pref[p]+=1
print('=== EMITS_NOTHING: biggest id-prefix families (systemic candidates) ===')
for p,n in pref.most_common(18):
    if n>=4: print(f'  {n:4d}  {p}*')
open(f'{D}/remain_coll.txt','w').write('\n'.join(s for _,s,_ in coll)+'\n')
open(f'{D}/remain_en.txt','w').write('\n'.join(sorted(en))+'\n')
print(f'\n  wrote {len(coll)} collision + {len(en)} emits-nothing ids')
