#!/usr/bin/env python3
"""Run pivot rows through the real binary WITH an entity, on a fresh copy of a
warmed template DB each, and report emitted vs stored vs db_rows — the same
two-independent-readings discipline as tools/audit_registry_emit.py, which
cannot supply entities and therefore cannot exercise these rows.

input TSV: id<TAB>entity ; output TSV columns mirror audit_registry_emit.
"""
import os, re, shutil, sqlite3, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

BIN = sys.argv[1]
IDS = sys.argv[2]
OUT = sys.argv[3]
JOBS = int(sys.argv[4]) if len(sys.argv) > 4 else 4
TIMEOUT = 300

SCHED = re.compile(r"\[sched\] (\S+) run rc=(-?\d+) records=(-?\d+) (\d+)ms")
STORED = re.compile(r"\bstored=(\?|>=\d+|\d+)")
HP_EMIT = re.compile(r"\[hp:[^\]]+\] emitted (\d+) of (\d+) available")

work = tempfile.mkdtemp(prefix="jo_entrun_", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)
tpl = os.path.join(work, "template.db")
env0 = dict(os.environ, JO_DB=tpl, JO_FTS_REBUILD="0")
subprocess.run([BIN, "--list-sources"], capture_output=True, env=env0, timeout=900)
con = sqlite3.connect(tpl); con.execute("PRAGMA wal_checkpoint(TRUNCATE)"); con.close()

def one(pair):
    sid, ent = pair
    d = os.path.join(work, re.sub(r"[^A-Za-z0-9_]", "_", sid))
    os.makedirs(d, exist_ok=True)
    db = os.path.join(d, "run.db")
    shutil.copy(tpl, db)
    env = dict(os.environ, JO_DB=db, JO_FTS_REBUILD="0")
    try:
        p = subprocess.run([BIN, "--run", sid, ent], capture_output=True,
                           text=True, errors="replace", env=env, timeout=TIMEOUT)
        blob = (p.stdout or "") + (p.stderr or "")
        rc = p.returncode
    except subprocess.TimeoutExpired as e:
        blob = ((e.stdout or b"").decode("utf-8", "replace") if isinstance(e.stdout, bytes) else (e.stdout or "")) + \
               ((e.stderr or b"").decode("utf-8", "replace") if isinstance(e.stderr, bytes) else (e.stderr or ""))
        rc = "TIMEOUT"
    m = SCHED.search(blob)
    emitted = int(m.group(3)) if m else -1
    sched_rc = int(m.group(2)) if m else None
    ms = STORED.search(blob[m.end():m.end()+80]) if m else None
    stored = ms.group(1) if ms else "?"
    he = HP_EMIT.search(blob)
    avail = int(he.group(2)) if he else -1
    try:
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
        rows = con.execute("SELECT COUNT(*) FROM intel_items WHERE source_id=?", (sid,)).fetchone()[0]
        con.close()
    except Exception:
        rows = -1
    tail = ""
    for ln in reversed(blob.splitlines()):
        if sid in ln or "[hp:" in ln:
            tail = ln.strip()[:160]
            break
    shutil.rmtree(d, ignore_errors=True)
    return "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s" % (sid, ent, rc, sched_rc, emitted, stored, rows, tail)

pairs = []
for ln in open(IDS, encoding="utf-8"):
    ln = ln.strip()
    if ln and "\t" in ln:
        a, b = ln.split("\t", 1)
        pairs.append((a, b))

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("id\tentity\trc\tsched_rc\temitted\tstored\tdb_rows\tnote\n")
    with ThreadPoolExecutor(max_workers=JOBS) as ex:
        for res in ex.map(one, pairs):
            fh.write(res + "\n"); fh.flush()
shutil.rmtree(work, ignore_errors=True)
print("done", len(pairs))
