#!/usr/bin/env python3
"""Liveness probe for hand-written pivot rows: substitute a representative
entity per token, GET the URL, record status. A 4xx on a nonsense entity still
proves host+path answer; only transport failure / bot-wall is a real problem."""
import sys, ssl, socket
import urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor

UA = 'JapanOSINT/1.0 (+https://github.com/rcorp/japanosint)'
SUB = [('{q}', 'Toyota'), ('{Q}', 'Toyota'), ('{qU}', 'TOYOTA'),
       ('{qd}', '1'), ('{qh}', '8.8.8.8'), ('{qD}', 'toyota.com'),
       ('{qe}', 'info@toyota.com')]

def probe(line):
    parts = line.rstrip('\n').split('\t')
    rid, url = parts[0], parts[3]
    for a, b in SUB:
        url = url.replace(a, b)
    req = urllib.request.Request(url, headers={'User-Agent': UA,
                                               'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            body = r.read(2048)
            return '%s\t%d\t%d\t%s' % (rid, r.status, len(body), url)
    except urllib.error.HTTPError as e:
        return '%s\t%d\t\t%s' % (rid, e.code, url)
    except Exception as e:
        return '%s\tXPORT\t%s\t%s' % (rid, str(e)[:100].replace('\t', ' '), url)

lines = [l for l in open(sys.argv[1], encoding='utf-8') if l.strip()]
with ThreadPoolExecutor(max_workers=6) as ex:
    for res in ex.map(probe, lines):
        print(res, flush=True)
