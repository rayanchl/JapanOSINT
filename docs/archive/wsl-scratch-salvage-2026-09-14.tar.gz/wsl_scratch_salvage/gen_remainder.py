import csv, os
D='/home/rayan/jo_audit_2026_09_03/audit_run'
ROOT='/mnt/c/Users/rayan/sources/repos/OSINTsaas'
OUT='/mnt/c/Users/rayan/AppData/Local/Temp/claude/C--Users-rayan-sources-repos-OSINTsaas/01ad357a-fa39-4a04-ac50-ca8974241981/scratchpad'
N=8
new={r['id']:r for r in csv.DictReader(open(f'{D}/fixpass_sweep.tsv',encoding='utf-8'),delimiter='\t')}
ids=[l.strip() for l in open(f'{D}/remain_collision_other.txt') if l.strip()]
ids+=[l.strip() for l in open(f'{D}/remain_emits_nothing.txt') if l.strip()]
ids=sorted(set(ids))
print('remainder ids:',len(ids))
# map id -> file by scanning collector .c files once
files={}
for dp,_,fn in os.walk(f'{ROOT}/native/collectors'):
    for f in fn:
        if not f.endswith('.c'): continue
        p=os.path.join(dp,f)
        try: txt=open(p,encoding='utf-8',errors='replace').read()
        except: continue
        for sid in ids:
            if f'"{sid}"' in txt: files.setdefault(os.path.relpath(p,ROOT).replace(os.sep,'/'),[]).append(sid)
print('files:',len(files))
items=sorted(files.items(),key=lambda kv:-len(kv[1]))
bins=[[] for _ in range(N)]; loads=[0]*N
for f,sids in items:
    i=loads.index(min(loads)); bins[i].append((f,sids)); loads[i]+=len(sids)
for i in range(N):
    lines=[]
    for f,sids in bins[i]:
        lines.append(f'## {f}  ({len(sids)} defective ids)')
        for sid in sorted(sids):
            r=new[sid]
            if r['verdict']=='COLLISION':
                e,s=int(r['emitted']),int(r['stored'])
                lines.append(f'  COLLISION  {sid}\temitted={e} stored={s} lost={e-s} ({100*(e-s)/e:.1f}%)')
            else:
                lines.append(f'  EMITS_NOTHING  {sid}')
    open(f'{OUT}/manifest_r{i}.txt','w',encoding='utf-8').write('\n'.join(lines)+'\n')
    print(f'group r{i}: {len(bins[i])} files, {loads[i]} ids')
