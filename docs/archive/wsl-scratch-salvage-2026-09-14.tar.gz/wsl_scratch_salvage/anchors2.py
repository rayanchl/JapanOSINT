import sys, re, json, socket, urllib.request, ssl, gzip, collections, html as H, time
_orig = socket.getaddrinfo
def _gai(*a, **k):
    r = _orig(*a, **k); v4 = [x for x in r if x[0] == socket.AF_INET]; return v4 or r
socket.getaddrinfo = _gai
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA = "Mozilla/5.0 (X11; Linux x86_64) JapanOSINT/1.0"
def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*", "Accept-Encoding": "gzip"})
    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
        b = r.read(3000000)
        if r.headers.get("Content-Encoding")=="gzip":
            try: b=gzip.decompress(b)
            except Exception: pass
        return r.status, b
for spec in [l.rstrip("\n") for l in open(sys.argv[1], encoding="utf-8") if l.strip() and not l.startswith("#")]:
    mode, url = spec.split("\t",1) if "\t" in spec else ("A", spec)
    print("=====", mode, url, flush=True)
    try:
        st, b = get(url)
    except Exception as e:
        print("  ERR", str(e)[:100]); continue
    txt=None
    for enc in ("utf-8","cp932","euc-jp"):
        try: txt=b.decode(enc); break
        except Exception: pass
    if txt is None: txt=b.decode("utf-8","replace")
    if mode=="B":
        print("  ", re.sub(r"\s+"," ",txt[:1500])); continue
    hrefs = re.findall(r'<a\b[^>]*?href="([^"#]+)"[^>]*>(.*?)</a>', txt, re.S|re.I)
    c = collections.Counter(); samp = collections.defaultdict(list)
    for h,a in hrefs:
        h2 = re.sub(r"^https?://[^/]+", "", h)
        segs = [s for s in h2.split("/") if s]
        pre = "/" + "/".join(segs[:2]) if h2.startswith("/") else h2[:25]
        pre = re.sub(r"\d{4,}", "#", pre)
        c[pre]+=1
        t = H.unescape(re.sub(r"<[^>]+>","",a)).strip()
        if len(samp[pre])<2 and t: samp[pre].append((h[:80], t[:50]))
    print("  anchors=%d" % len(hrefs))
    for pre,n in c.most_common(14):
        print("   %4d %-40s %s" % (n, pre, samp[pre]))
    time.sleep(0.3)
