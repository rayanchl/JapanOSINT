import sys, re, json, socket, urllib.request, ssl, gzip, concurrent.futures as cf, time, collections, html as H
_orig = socket.getaddrinfo
def _gai(*a, **k):
    r = _orig(*a, **k); v4 = [x for x in r if x[0] == socket.AF_INET]; return v4 or r
socket.getaddrinfo = _gai
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
DEFUA = "Mozilla/5.0 (X11; Linux x86_64) JapanOSINT/1.0"
def fetch(spec):
    parts = spec.split("\t"); url = parts[0]; ua = parts[1] if len(parts) > 1 and parts[1] else DEFUA
    t=time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept": "*/*", "Accept-Encoding": "gzip"})
        with urllib.request.urlopen(req, timeout=25, context=ctx) as r:
            b = r.read(900000); ct = r.headers.get("Content-Type",""); st=r.status
            if r.headers.get("Content-Encoding")=="gzip":
                try: b=gzip.decompress(b)
                except Exception: pass
    except urllib.error.HTTPError as e:
        return "%s\tHTTP%d\t%.1fs" % (url, e.code, time.time()-t)
    except Exception as e:
        return "%s\tERR %s\t%.1fs" % (url, str(e)[:60], time.time()-t)
    enc=None
    for cand in ("utf-8","cp932","euc-jp"):
        try: txt=b.decode(cand); enc=cand; break
        except Exception: continue
    if enc is None: txt=b.decode("utf-8","replace"); enc="?"
    s=txt.lstrip(); out=[]
    head = "%s\t%d %s\t%s\t%.1fs\t%dB" % (url, st, ct[:30], enc, time.time()-t, len(b))
    if s.startswith("{") or s.startswith("["):
        try:
            j=json.loads(txt)
            if isinstance(j,list): out.append("json list[%d] first=%s" % (len(j), json.dumps(j[0], ensure_ascii=False)[:300] if j else ""))
            else:
                out.append("json keys=%s" % ",".join(list(j.keys())[:10]))
                for k,v in j.items():
                    if isinstance(v,list) and v: out.append("  %s: list[%d] first=%s" % (k, len(v), json.dumps(v[0], ensure_ascii=False)[:300])); break
                    if isinstance(v,dict):
                        for k2,v2 in v.items():
                            if isinstance(v2,list) and v2: out.append("  %s.%s: list[%d] first=%s" % (k,k2,len(v2), json.dumps(v2[0], ensure_ascii=False)[:300])); break
        except Exception as e: out.append("json? %s" % str(e)[:40])
    elif ("<rss" in s[:1500] or "<feed" in s[:1500] or "<rdf:RDF" in s[:1500] or "<OAI-PMH" in s[:600]) and "<html" not in s[:600].lower():
        tot = re.search(r"totalResults>(\d+)", txt)
        titles = re.findall(r"<title[^>]*>(.*?)</title>", txt, re.S)[1:6]
        out.append("feed items=%d entries=%d records=%d total=%s titles=%s" % (txt.count("<item"), txt.count("<entry"), txt.count("<record"), tot.group(1) if tot else "-", [H.unescape(re.sub(r"<!\[CDATA\[|\]\]>","",x)).strip()[:60] for x in titles]))
    elif "<html" in s[:3000].lower() or "<!doctype" in s[:300].lower():
        hrefs = re.findall(r'<a[^>]+href="([^"#]+)"[^>]*>(.*?)</a>', txt, re.S|re.I)
        c = collections.Counter()
        samp = {}
        for h,a in hrefs:
            h2 = re.sub(r"^https?://[^/]+", "", h)
            pre = "/".join(h2.split("/")[:3]) if h2.startswith("/") else h2[:30]
            c[pre]+=1
            if pre not in samp: samp[pre]=(h[:70], H.unescape(re.sub(r"<[^>]+>","",a)).strip()[:40])
        out.append("html anchors=%d" % len(hrefs))
        for pre,n in c.most_common(8): out.append("  %3d %s  e.g. %s  '%s'" % (n, pre, samp[pre][0], samp[pre][1]))
        feeds = re.findall(r'href="([^"]*(?:\.rss|\.rdf|\.xml|/feed/?|atom)[^"]*)"', txt, re.I)
        if feeds: out.append("  feeds=%s" % sorted(set(feeds))[:8])
    else:
        lines = txt.splitlines()
        out.append("text lines=%d first=%s" % (len(lines), " || ".join(l[:80] for l in lines[:6])))
    return head + "\n    " + "\n    ".join(out)
specs=[l.rstrip("\n") for l in open(sys.argv[1], encoding="utf-8") if l.strip() and not l.startswith("#")]
with cf.ThreadPoolExecutor(8) as ex:
    for line in ex.map(fetch, specs):
        print(line, flush=True)
