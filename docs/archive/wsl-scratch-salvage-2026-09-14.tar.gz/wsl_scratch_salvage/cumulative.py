import csv, os
D='/home/rayan/jo_audit_2026_09_03/audit_run'
def load(p):
    r={}
    if not os.path.exists(p): return r
    with open(p, encoding='utf-8') as f:
        for row in csv.DictReader(f, delimiter='\t'):
            r[row['id']]=row
    return r
base=load(f'{D}/fixpass_sweep.tsv')      # all 1770 after rounds 1-2
r3=load(f'{D}/round3_sweep.tsv')         # 510
r45=load(f'{D}/r45_sweep.tsv')           # 511
# original defective set = the 1770
orig=set(base)
cur={}
for sid in orig:
    cur[sid]= r45.get(sid) or r3.get(sid) or base.get(sid)
pivot=set()
with open(f'{D}/id_interval.tsv', encoding='utf-8') as f:
    for line in f:
        p=line.rstrip('\n').split('\t')
        if len(p)==2 and p[1]=='interval=0': pivot.add(p[0])
tally={}; lost=0
for sid,row in cur.items():
    v=row['verdict']
    tally[v]=tally.get(v,0)+1
    if v=='COLLISION':
        try: lost+=max(int(row['emitted'])-int(row['stored']),0)
        except: pass
print('=== CUMULATIVE: the original 1,770 defective ids, current measured state ===')
for k,v in sorted(tally.items(), key=lambda x:-x[1]):
    print(f'  {k:16s} {v}')
print()
print('  collision records still lost per pass:', f'{lost:,}')
print('  (was 205,617 at the start of the fix work)')
never=[s for s in orig if s not in r3 and s not in r45]
print()
print('  of these, never re-measured since rounds 1-2 (r6/r7 territory):', len(never))
