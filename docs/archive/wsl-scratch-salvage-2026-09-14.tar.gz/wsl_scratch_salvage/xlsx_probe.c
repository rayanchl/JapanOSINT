/* scratch driver: xlsx_probe <file.xlsx> [sheet] — sheet names, dims, head */
#include "lib/xlsx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "rb"); if (!f) return 2;
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  char *b = malloc((size_t)n); if (fread(b, 1, (size_t)n, f) != (size_t)n) return 2; fclose(f);
  char err[512] = "";
  char *names = xlsx_sheet_names(b, (size_t)n, err, sizeof err);
  printf("sheets: %s  (err=%s)\n", names ? names : "(null)", err);
  free(names);
  char *csv = NULL; size_t cl = 0;
  int rc = xlsx_to_csv(b, (size_t)n, 0, argc > 2 ? argv[2] : NULL, &csv, &cl, err, sizeof err);
  printf("rc=%d len=%zu err=%s\n", rc, cl, err);
  if (rc) return 1;
  size_t lines = 0, nonempty = 0; const char *p = csv;
  for (size_t i = 0; i < cl; i++) if (csv[i] == '\n') { lines++; if (csv[i - 1] != '\n' && i > 0 && p[0] != '\n') nonempty++; }
  printf("lines=%zu\n", lines);
  int shown = 0; p = csv;
  while (*p && shown < 6) { const char *e = strchr(p, '\n'); size_t l = e ? (size_t)(e - p) : strlen(p);
    printf("%d: %.*s\n", shown + 1, (int)(l > 200 ? 200 : l), p); shown++; if (!e) break; p = e + 1; }
  free(csv); free(b); return 0;
}
