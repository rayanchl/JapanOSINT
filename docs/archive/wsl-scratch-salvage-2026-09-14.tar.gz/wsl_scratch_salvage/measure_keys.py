#!/usr/bin/env python3
"""Measure per-field distinct-count/coverage over a row's live records and
propose an id_keys that is unique per record. Read-only helper for Agent A;
lives outside the repo. Mirrors hp_flatten (dotted keys, arrays as .N) and
hp_pick_s (single field, first match wins) so a proposal means something."""
import argparse, csv as csvmod, io, json, re, sys, os
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = "/home/rayan/jo_A/native/tools"
sys.path.insert(0, TOOLS)
from manifest import load, parse_opts            # noqa: E402
from probe_hp_batch import fetch, row_headers    # noqa: E402

HP_MAX_ARR = 40
IDISH = re.compile(r"(?:^|[._])(id|uid|uuid|key|code|number|guid|slug|ref|"
                   r"identifier|accession|objectid|recordid|hash)s?$", re.I)

def flatten(node, prefix, out, depth):
    if depth > 6 or len(out) > 400:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            put(key, v, out, depth)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            if i >= HP_MAX_ARR:
                break
            key = f"{prefix}.{i}" if prefix else str(i)
            put(key, v, out, depth)

def put(key, v, out, depth):
    if isinstance(v, str):
        if v:
            out[key] = v
    elif isinstance(v, bool):
        out[key] = "true" if v else "false"
    elif isinstance(v, (int, float)):
        out[key] = repr(v)
    elif isinstance(v, (dict, list)):
        flatten(v, key, out, depth + 1)

def descend(doc, path):
    """array_path: dotted, each segment a key or key=value filter on a list."""
    cur = doc
    for seg in path.split("."):
        if cur is None:
            return None
        if isinstance(cur, list):
            if "=" in seg:
                k, _, want = seg.partition("=")
                cur = next((e for e in cur if isinstance(e, dict)
                            and str(e.get(k)) == want), None)
                continue
            if seg.isdigit():
                idx = int(seg)
                cur = cur[idx] if idx < len(cur) else None
                continue
            cur = [e.get(seg) for e in cur if isinstance(e, dict)]
            continue
        if isinstance(cur, dict):
            cur = cur.get(seg)
        else:
            return None
    return cur

def biggest_array(doc, best=None):
    if isinstance(doc, list):
        dicts = [e for e in doc if isinstance(e, dict)]
        if len(dicts) >= 2 and (best is None or len(dicts) > len(best)):
            best = dicts
        for e in doc:
            best = biggest_array(e, best)
    elif isinstance(doc, dict):
        for v in doc.values():
            best = biggest_array(v, best)
    return best

DELIMS = {"comma": ",", "pipe": "|", "tab": "\t", "semi": ";"}

def parse_records(row, o, raw):
    mode = row["mode"]
    text = raw.decode("utf-8", "replace")
    if mode == "json":
        doc = json.loads(text)
        ap = o.get("array_path")
        arr = descend(doc, ap) if ap else None
        if not isinstance(arr, list):
            arr = biggest_array(doc)
        if arr is None and isinstance(doc, list):
            arr = doc
        return [r for r in (arr or []) if isinstance(r, dict)] or \
               [{"value": str(r)} for r in (arr or [])]
    if mode == "csv":
        d = DELIMS.get(o.get("csv_delim", "comma"), ",")
        cmt = o.get("csv_comment")
        lines = [ln for ln in text.splitlines()
                 if ln.strip() and not (cmt and ln.lstrip().startswith(cmt))]
        rd = list(csvmod.reader(io.StringIO("\n".join(lines)), delimiter=d))
        if not rd:
            return []
        if o.get("csv_no_header"):
            hdr = ["col%d" % i for i in range(len(rd[0]))]
            body = rd
        else:
            hdr, body = rd[0], rd[1:]
        out = []
        for r in body:
            out.append({hdr[i] if i < len(hdr) else "col%d" % i: v
                        for i, v in enumerate(r) if v})
        return out
    if mode == "xml":
        try:
            root = ET.fromstring(text)
        except ET.ParseError:
            return []
        best, bestp = 0, None
        for parent in root.iter():
            from collections import Counter
            tally = Counter(c.tag.rsplit("}", 1)[-1] for c in list(parent))
            if tally:
                tag, n = tally.most_common(1)[0]
                if n > best:
                    best, bestp, besttag = n, parent, tag
        if not bestp:
            return []
        def xml2d(el, d, prefix, depth):
            if depth > 5:
                return
            for k, v in el.attrib.items():
                key = (prefix + "." if prefix else "") + "@" + k
                if v:
                    d[key] = v
            from collections import Counter
            for ch in el:
                tag = ch.tag.rsplit("}", 1)[-1]
                key = (prefix + "." if prefix else "") + tag
                if len(ch) or ch.attrib:
                    xml2d(ch, d, key, depth + 1)
                if ch.text and ch.text.strip():
                    d.setdefault(key, ch.text.strip())
            if el.text and el.text.strip() and not prefix:
                d.setdefault("_text", el.text.strip())
        out = []
        for el in bestp:
            if el.tag.rsplit("}", 1)[-1] != besttag:
                continue
            d = {}
            xml2d(el, d, "", 0)
            if d:
                out.append(d)
        return out
    return []

def page_urls(row, o, base):
    urls = [base]
    pp = o.get("page_param")
    if pp:
        start = int(o.get("page_start", "1") or 1)
        if o.get("page_zero_based"):
            start = 0
        # offset-style params step by page_size, mirroring hpengine
        size = int(o.get("page_size", "0") or 0)
        offset_style = size > 0 or any(w in pp for w in ("offset", "start", "skip"))
        if offset_style:
            step = size if size > 0 else 100
            vals = (start + step, start + 2 * step)
        else:
            vals = (start + 1, start + 2)
        sep = "&" if "?" in base else "?"
        for p in vals:
            if re.search(r"[?&]%s=" % re.escape(pp), base):
                urls.append(re.sub(r"([?&]%s=)\d+" % re.escape(pp),
                                   lambda m: "%s%d" % (m.group(1), p), base))
            else:
                urls.append("%s%s%s=%d" % (base, sep, pp, p))
    return urls

def measure(row):
    o, _d, _j = parse_opts(row["opts"])
    url = row["url"]
    if "{" in url:
        url = row["probe"]
    if "{" in url:
        return dict(id=row["id"], verdict="NEEDS_ENTITY", n=0)
    hdrs = row_headers(row)
    allrec = []
    pages = 0
    seen_first = None
    for u in page_urls(row, o, url):
        try:
            st = None
            for attempt in range(3):
                try:
                    st, ct, raw = fetch(u, hdrs)
                    break
                except Exception as e:
                    msg = str(e)
                    if attempt < 2 and ("resolution" in msg or "unreachable" in msg
                                        or "associated" in msg):
                        import time
                        time.sleep(4)
                        continue
                    raise
        except Exception as e:
            if pages == 0:
                return dict(id=row["id"], verdict="FETCH_FAIL:%s" % str(e)[:80], n=0)
            break
        if st != 200:
            if pages == 0:
                return dict(id=row["id"], verdict="HTTP_%s" % st, n=0)
            break
        recs = parse_records(row, o, raw)
        if not recs:
            break
        sig = json.dumps(recs[0], sort_keys=True)[:2000]
        if seen_first is not None and sig == seen_first:
            break  # page param ignored; don't double-count
        seen_first = sig if pages == 0 else seen_first
        allrec.extend(recs)
        pages += 1
        if not o.get("page_param"):
            break
    n = len(allrec)
    if n == 0:
        return dict(id=row["id"], verdict="NO_RECORDS", n=0)
    flats = []
    seen_flat = set()
    for r in allrec:
        f = {}
        flatten(r, "", f, 0)
        sig = json.dumps(f, sort_keys=True)
        if sig in seen_flat:
            continue          # page overlap / byte-identical dupe: measure once
        seen_flat.add(sig)
        flats.append(f)
    n = len(flats)
    stats = {}
    for f in flats:
        for k, v in f.items():
            s = stats.setdefault(k, [0, set()])
            s[0] += 1
            if len(s[1]) < n + 1:
                s[1].add(v)
    uniq_recs = n   # flats are deduped above; n IS the distinct-record count
    cands = []
    for k, (present, vals) in stats.items():
        cands.append((k, present, len(vals)))
    full = [c for c in cands if c[1] == n and c[2] == n]
    full.sort(key=lambda c: (0 if IDISH.search(c[0]) else 1, c[0].count("."), len(c[0])))
    near = sorted(cands, key=lambda c: (-(c[2]), c[0].count(".")))[:6]
    return dict(id=row["id"], verdict="UNIQUE" if full else "NONE", n=n,
                pages=pages, uniq_recs=uniq_recs,
                cur=o.get("id_keys", ""),
                best=full[0][0] if full else "",
                full=";".join(c[0] for c in full[:6]),
                near=";".join("%s=%d/%d" % (c[0], c[2], c[1]) for c in near))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifests", nargs="+")
    ap.add_argument("--only", required=True)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    want = set(x.strip() for x in open(a.only).read().replace(",", "\n").split())
    rows, _problems = load(a.manifests, strict=False)
    rows = [r for r in rows if r["id"] in want]
    sys.stderr.write("measuring %d rows\n" % len(rows))
    from concurrent.futures import ThreadPoolExecutor
    with open(a.out, "w") as fh:
        fh.write("id\tverdict\tn\tpages\tuniq_recs\tcur_id_keys\tbest\tall_unique\tnear\n")
        with ThreadPoolExecutor(a.jobs) as ex:
            for res in ex.map(lambda r: measure(r), rows):
                fh.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (
                    res["id"], res["verdict"], res.get("n", 0),
                    res.get("pages", 0), res.get("uniq_recs", ""),
                    res.get("cur", ""), res.get("best", ""),
                    res.get("full", ""), res.get("near", "")))
                fh.flush()

if __name__ == "__main__":
    main()
