#!/usr/bin/env python3
"""A deterministic stand-in for an embedding llama-server.

This is NOT a model. It exists to exercise the CODE PATH in
core/service_vec.c end to end on a host with no .gguf: index build, batching,
vec0 insert, nearest-neighbour query, and the dim-mismatch refusal. Vectors
are a hashed bag-of-words, so "who owns this domain" lands near a service
whose description contains those words and far from one that does not — good
enough to prove routing works, and it is never presented as semantic quality.

  /v1/embeddings  {input:[...], model:...} -> {data:[{index,embedding:[...]}]}
  /v1/models      -> {data:[{id: <model>}]}

DIM is settable so a second run at a different dimension can prove the
refusal-to-mix-spaces path fires.
"""
import hashlib
import json
import os
import re
from http.server import BaseHTTPRequestHandler, HTTPServer

DIM = int(os.environ.get("FAKE_EMBED_DIM", "64"))
MODEL = os.environ.get("FAKE_EMBED_MODEL", "stub-hash-v1")


def vec(text):
    v = [0.0] * DIM
    for w in re.findall(r"[a-z0-9]+", (text or "").lower()):
        h = int(hashlib.sha1(w.encode()).hexdigest()[:8], 16)
        v[h % DIM] += 1.0
    n = sum(x * x for x in v) ** 0.5
    return [x / n for x in v] if n else [0.0] * DIM


class H(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith("/v1/models"):
            return self._send({"data": [{"id": MODEL}]})
        if self.path.startswith("/health"):
            return self._send({"status": "ok"})
        self._send({"error": "not found"}, 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._send({"error": "bad json"}, 400)
        if not self.path.startswith("/v1/embeddings"):
            return self._send({"error": "not found"}, 404)
        inp = body.get("input", [])
        if isinstance(inp, str):
            inp = [inp]
        self._send({
            "object": "list",
            "model": MODEL,
            "data": [{"object": "embedding", "index": i, "embedding": vec(t)}
                     for i, t in enumerate(inp)],
        })

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    port = int(os.environ.get("FAKE_EMBED_PORT", "8099"))
    print("fake-embed on :%d dim=%d model=%s" % (port, DIM, MODEL), flush=True)
    HTTPServer(("127.0.0.1", port), H).serve_forever()
