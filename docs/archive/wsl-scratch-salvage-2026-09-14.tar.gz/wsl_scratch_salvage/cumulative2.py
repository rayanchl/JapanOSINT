import csv, os
D='/home/rayan/jo_audit_2026_09_03/audit_run'
def load(p):
    r={}
    if not os.path.exists(p): return r
    with open(p, encoding='utf-8') as f:
        for row in csv.DictReader(f, delimiter='\t'): r[row['id']]=row
    return r
base=load(f'{D}/fixpass_sweep.tsv'); r3=load(f'{D}/round3_sweep.tsv')
r45=load(f'{D}/r45_sweep.tsv');      r67=load(f'{D}/r67_sweep.tsv')
cur={}
for sid in base:
    cur[sid]= r67.get(sid) or r45.get(sid) or r3.get(sid) or base[sid]
tally={}; lost=0
for sid,row in cur.items():
    v=row['verdict']; tally[v]=tally.get(v,0)+1
    if v=='COLLISION':
        try: lost+=max(int(row['emitted'])-int(row['stored']),0)
        except: pass
print('=== CUMULATIVE (original 1,770 defective ids, all measured) ===')
for k,v in sorted(tally.items(), key=lambda x:-x[1]): print(f'  {k:16s} {v}')
print(f'\n  collision records still lost per pass: {lost:,}   (start: 205,617)')
print(f'  recovered: {205617-lost:,} records per pass')
stale=[s for s in base if s not in r3 and s not in r45 and s not in r67]
print(f'\n  still carrying round-1/2 verdicts (never re-measured): {len(stale)}')
