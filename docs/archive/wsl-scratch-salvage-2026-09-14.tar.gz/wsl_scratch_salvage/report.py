#!/usr/bin/env python3
"""Turn the live-sweep JSONL into the audit report.

Answers the questions the audit was asked: does each source produce real data,
can it produce a map pin, is what it collects exhaustive, and where do the
structures disagree.
"""
import argparse
import collections
import json
import sys


def load(path):
    rows = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return rows


def pct(n, d):
    return f"{100.0 * n / d:.1f}%" if d else "n/a"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--ids", help="ids.tsv; a 2nd column marks an entity-pivot service")
    ap.add_argument("--top", type=int, default=25)
    a = ap.parse_args()
    R = load(a.results)
    n = len(R)

    # Entity-pivot services are lookups, not map layers: judging them on geo
    # coverage would be judging a WHOIS client for not having coordinates.
    # Keeping them in one bucket with the map collectors understated the map
    # collectors' pin rate by ~2.5x.
    svc_ids = set()
    if a.ids:
        with open(a.ids, encoding="utf-8") as fh:
            for line in fh:
                p = line.rstrip("\n").split("\t")
                if len(p) > 1 and p[1].strip():
                    svc_ids.add(p[0].strip())
    print(f"# Collector audit — {n} sources run live\n")

    # ── 1. verdict distribution ───────────────────────────────────────────
    v = collections.Counter(r.get("verdict") for r in R)
    print("## Verdicts")
    for k, c in v.most_common():
        print(f"  {k:14s} {c:5d}  {pct(c, n)}")

    # ── 2. map-pin capability ─────────────────────────────────────────────
    data = [r for r in R if r.get("verdict") == "DATA"]
    mapc = [r for r in data if r["id"] not in svc_ids]
    svc = [r for r in data if r["id"] in svc_ids]

    print("\n## Map-pin capability")
    for label, rs in (("map collectors", mapc), ("entity-pivot services", svc)):
        if not rs:
            continue
        pin = [r for r in rs if r.get("geo_rows", 0) > 0]
        geom = [r for r in rs if not r.get("geo_rows") and r.get("geometry_rows")]
        none = [r for r in rs
                if not r.get("geo_rows") and not r.get("geometry_rows")]
        print(f"  {label:22s} n={len(rs):4d}  pins={len(pin):4d} "
              f"({pct(len(pin), len(rs))})  geometry-only={len(geom):3d}  "
              f"no-geo={len(none):4d}")
    print("  (services are lookups, not layers — no-geo is correct for them)")

    # Partial geo is the interesting bucket: the source CAN geocode but some of
    # its rows land without coordinates, so that share never reaches the map.
    partial = [r for r in data
               if r.get("geo_rows", 0) and r["geo_rows"] < r["rows"]]
    partial.sort(key=lambda r: (r["rows"] - r["geo_rows"]), reverse=True)
    print(f"\n### Partially geocoded — rows that will never render ({len(partial)})")
    for r in partial[:a.top]:
        miss = r["rows"] - r["geo_rows"]
        print(f"  {r['id']:34s} {r['geo_rows']:5d}/{r['rows']:<5d} geo  "
              f"({miss} rows invisible, {pct(miss, r['rows'])})")
    if not partial:
        print("  (none — every geocoding source geocodes all of its rows)")

    # ── 3. thin data ──────────────────────────────────────────────────────
    print("\n## Thin payloads (rows present, key fields empty)")
    thin = []
    for r in data:
        f, rows = r.get("fill", {}), r["rows"]
        if not rows:
            continue
        missing = [k for k in ("title", "link", "published_at")
                   if f.get(k, 0) == 0]
        if missing:
            thin.append((r["id"], rows, missing))
    thin.sort(key=lambda t: -t[1])
    for sid, rows, missing in thin[:a.top]:
        print(f"  {sid:34s} rows={rows:<6d} always-empty: {','.join(missing)}")
    if not thin:
        print("  (none)")

    # ── 4. single-row sources ─────────────────────────────────────────────
    # A collector that emits exactly one row is usually a portal/probe stub
    # rather than a real feed — worth separating from genuine collectors.
    ones = sorted([r["id"] for r in data if r["rows"] == 1])
    print(f"\n## Single-row sources ({len(ones)}) — probe stubs, not feeds")
    for i in range(0, min(len(ones), 40), 4):
        print("  " + "  ".join(f"{x:26s}" for x in ones[i:i + 4]))

    # ── 5. record_type hygiene ────────────────────────────────────────────
    print("\n## record_type usage")
    rt = collections.Counter()
    selfnamed = []
    for r in data:
        for t in r.get("record_types", []):
            rt[t] += 1
        if r.get("record_types") == [r["id"]]:
            selfnamed.append(r["id"])
    for t, c in rt.most_common(20):
        print(f"  {t:34s} {c}")
    print(f"\n  sources whose record_type is just their own id: {len(selfnamed)}")
    print("  (defeats cross-source filtering by type — every one is its own type)")
    for i in range(0, min(len(selfnamed), 24), 3):
        print("    " + "  ".join(f"{x:30s}" for x in selfnamed[i:i + 3]))

    # ── 6. failures worth a human ─────────────────────────────────────────
    for bucket in ("CRASH", "RC_ERROR", "TIMEOUT", "NO_RUN", "HARNESS_ERROR",
                   "DB_ERROR", "NO_TITLE"):
        rs = [r for r in R if r.get("verdict") == bucket]
        if not rs:
            continue
        print(f"\n## {bucket} ({len(rs)})")
        for r in sorted(rs, key=lambda x: x["id"])[:a.top]:
            tail = [x for x in (r.get("stderr_tail") or "").splitlines()
                    if x.strip() and not x.startswith("[db]")]
            hint = tail[-1][:110] if tail else (r.get("harness_error") or "")
            print(f"  {r['id']:34s} {hint}")
        if len(rs) > a.top:
            print(f"  … and {len(rs) - a.top} more")

    # ── 7. empties ────────────────────────────────────────────────────────
    empt = [r for r in R if r.get("verdict") == "EMPTY"]
    gated = [r for r in empt
             if "gated" in (r.get("stderr_tail") or "")
             or "no API key" in (r.get("stderr_tail") or "")
             or "not set" in (r.get("stderr_tail") or "")]
    print(f"\n## EMPTY ({len(empt)}): ran clean, persisted nothing")
    print(f"  explained by a missing key/config: {len(gated)}")
    print(f"  unexplained (upstream gave nothing, or a silent drop): "
          f"{len(empt) - len(gated)}")
    for r in sorted([e for e in empt if e not in gated],
                    key=lambda x: x["id"])[:a.top]:
        tail = [x for x in (r.get("stderr_tail") or "").splitlines()
                if x.strip() and not x.startswith("[db]")]
        print(f"  {r['id']:34s} {(tail[-1][:100] if tail else '(silent)')}")


if __name__ == "__main__":
    main()
