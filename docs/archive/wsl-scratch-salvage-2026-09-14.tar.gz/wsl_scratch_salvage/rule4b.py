#!/usr/bin/env python3
"""House rule 4b: emitting is not storing. Run every manifest row against its
own scratch DB and compare `emitted N` against the rows actually stored.

Each row gets a FRESH database so a stored count can only come from that run,
and the file is deleted immediately afterwards (disk discipline).
"""
import os
import re
import sqlite3
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
NATIVE = sys.argv[1]
BIN = sys.argv[2]
sys.path.insert(0, os.path.join(NATIVE, "tools"))
from audit_batch_emit import rows, entity_of, EMITTED           # noqa: E402

TIMEOUT = int(os.environ.get("R4B_TIMEOUT", "600"))
SCHEMA = os.path.join(NATIVE, "schema.sql")


def one(r):
    fd, db = tempfile.mkstemp(prefix="r4b_", suffix=".db", dir="/tmp")
    os.close(fd)
    os.unlink(db)
    env = dict(os.environ, JO_DB=db)
    ent = entity_of(r)
    cmd = [BIN, "--run", r["id"]] + ([ent] if ent else [])
    emitted = avail = -1
    note = ""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, env=env,
                           timeout=TIMEOUT, stdin=subprocess.DEVNULL)
        blob = (p.stdout or "") + (p.stderr or "")
        m = None
        for m in EMITTED.finditer(blob):
            pass
        if m:
            emitted, avail = int(m.group(2)), int(m.group(3))
        else:
            note = "no emitted line"
    except subprocess.TimeoutExpired:
        note = "timeout"
    stored = -1
    try:
        if os.path.exists(db):
            c = sqlite3.connect(db)
            stored = c.execute(
                "select count(*) from intel_items where source_id=?",
                (r["id"],)).fetchone()[0]
            c.close()
    except Exception as e:
        note = (note + " " + str(e)).strip()
    for suf in ("", "-wal", "-shm", "-journal"):
        try:
            os.unlink(db + suf)
        except OSError:
            pass
    verdict = "OK"
    if emitted < 0:
        verdict = "NO_RUN"
    elif stored < emitted:
        verdict = "LOSS"
    elif stored > emitted:
        verdict = "EXTRA"
    return (r["id"], verdict, emitted, avail, stored, note)


def main():
    rs, bad = rows(sys.argv[3:])
    if bad:
        print("MALFORMED", bad)
    print("rule 4b: %d rows, timeout=%ds" % (len(rs), TIMEOUT))
    out = []
    with ThreadPoolExecutor(max_workers=int(os.environ.get("R4B_JOBS", "3"))) as ex:
        for res in ex.map(one, rs):
            out.append(res)
    loss = [x for x in out if x[1] != "OK"]
    tot_e = sum(x[2] for x in out if x[2] > 0)
    tot_s = sum(x[4] for x in out if x[4] > 0)
    for x in sorted(out):
        print("%-38s %-6s emitted=%-7d available=%-7d stored=%-7d %s" % x)
    print("\ntotal emitted=%d stored=%d   non-OK=%d" % (tot_e, tot_s, len(loss)))


main()
